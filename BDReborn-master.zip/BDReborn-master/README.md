# [BDReborn](https://telegram.me/BDReborn)

**An advanced and powerful administration bot based on NEW TG-CLI


* * *

## Commands

| Use help |
|:--------|:------------|
| [#!/]help | just send help in your group and get the commands |

**You can use "#", "!", or "/" to begin all commands

* * *

# Installation

```sh
# Let's install the bot.
cd $HOME
git clone https://github.com/BeyondTeam/BDReborn.git
cd BDReborn
chmod +x beyond.sh
./beyond.sh install
./beyond.sh 
# Enter a phone number & confirmation code.

# For Auto Launch:
chmod 777 autobd.sh
screen ./autobd.sh
```
### One command
To install everything in one command, use:
```sh
cd $HOME && git clone https://github.com/BeyondTeam/BDReborn.git && cd BDReborn && chmod +x beyond.sh && ./beyond.sh install && ./beyond.sh

OR

cd $HOME && git clone https://github.com/BeyondTeam/BDReborn.git && cd BDReborn && chmod +x beyond.sh && ./beyond.sh install && chmod 777 autobd.sh && screen ./autobd.sh
```

* * *

# Support and Development

More information [Beyond Global Chat](https://t.me/joinchat/AAAAAEGaKOxC8K6cJ3bCcw)

# Special thanks to
[@nero_dev](https://telegram.me/nero_dev)

[@MrHalix](https://github.com/MrHalix)

[@Vysheng](https://github.com/vysheng)

* * *

# Developers!

[SoLiD](https://github.com/solid021) ([Telegram](https://telegram.me/SoLiD))

[To0fan](https://github.com/To0fan) ([Telegram](https://telegram.me/ToOfan))

[MAKAN](https://github.com/makanj) ([Telegram](https://telegram.me/MAKAN))

[Ali](https://github.com/ali-ghoghnoos) ([Telegram](https://telegram.me/Exacute))

[Rixel](https://github.com/Rixel) ([Telegram](https://telegram.me/Rixel))

[mamad-datak](https://github.com/datak137) ([Telegram](https://telegram.me/K_a_I_i_I_i_n_u_x))

[Civey](https://github.com/Oysof) ([Telegram](https://telegram.me/Civey))

### Our Telegram channel:

[@BeyondTeam](https://telegram.me/BeyondTeam)
